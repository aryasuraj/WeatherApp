import React from 'react'
import TempApp from './components/TempApp'

const App = () => {
  return (
    <div>
      <>

      {/* <h1 className='warm'>Weather Today</h1> */}
      <TempApp/>
      {/* <TempApp/>
      <TempApp/>
      <TempApp/> */}
      
      </>


    </div>
  )
}

export default App
